Track {index,number,integer} of {count,number,integer}	
{width}px	
0 {right} 0 0	
