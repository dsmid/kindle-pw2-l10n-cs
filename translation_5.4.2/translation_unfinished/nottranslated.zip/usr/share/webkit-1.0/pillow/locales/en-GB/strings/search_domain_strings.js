Baidu	
Baidu Baike	
Douban	
100pt	
