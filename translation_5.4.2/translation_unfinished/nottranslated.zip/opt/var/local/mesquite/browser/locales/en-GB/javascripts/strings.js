browserStrings	
Download {filename}?<br><br>Once the download is complete, the file will appear on the Home screen. &nbsp;Are you sure you wish to proceed?	
http://en.wikipedia.org/	
http://m.facebook.com/	
http://m.gmail.com/	
http://mobile.twitter.com/	
http://news.bbc.co.uk/	
http://uk.imdb.com/	
http://uk.yahoo.com/	
http://www.amazon.co.uk/	
http://www.dailymail.co.uk/	
http://www.google.co.uk/	
http://www.google.co.uk/search?q=	
s go function	
strings', 'object	
Web	
Web Browser downloaded {filename} successfully.	
Web Browser is unable to establish a secure connection. Do you still want to proceed?	
