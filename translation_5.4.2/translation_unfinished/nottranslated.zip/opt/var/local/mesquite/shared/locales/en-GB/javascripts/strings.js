Menu	
strings	
