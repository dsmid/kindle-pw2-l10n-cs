Aeroplane Mode must be turned off to use this feature.	
An error occurred. Please try again.	
Launch Wikipedia	
No network detected. Please check your connection and try again.	
No text was selected.	
No Wikipedia results were found for your selection.	
Open Wikipedia ▶	
Searching Wikipedia...	
Turn Off Aeroplane Mode	
Unable to contact the server. Please try again later.	
Waiting for connection...	
Wikipedia lookups are not available when using FreeTime.	
Wireless must be turned on to use this feature.	
