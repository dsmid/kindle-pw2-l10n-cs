Artists	
(cont.)	
Creatures	
Current Chapter	
Current Page	
Dates	
en-gb	
Entire Book	
Equations	
Events	
Holidays	
Hotels	
http://creativecommons.org/licenses/by-sa/3.0/	
Ingredients	
Location ${location}	
Locations ${start} - ${end}	
loc.${location}	
loc.${start} - ${end}	
Monsters	
Organisations	
Page ${page}	
Page ${start} - ${end}	
People	
Places	
Potions	
p.${page}	
p.${start} - ${end}	
Quotes	
Recipes	
Restaurants	
See more about this book.	
Showing ${range} of ${total}	
Spells	
Subject to a <span class="license">Creative Commons Licence</span>	
Terms	
Theorems	
This book does not contain X-Ray concepts.	
This chapter does not contain X-Ray concepts.	
This page does not contain X-Ray concepts.	
Works	
X-Ray	
X-Ray concepts are not yet available for this book. See additional book information.	
X-Ray is not available for this book	
