Aeroplane Mode must be turned off to use this feature.	
Comments	
Getting your settings...	
[n] characters over	
Shared successfully on Facebook and Twitter.	
Shared successfully on [n].	
Share on:	
Share on Weibo	
Share to Goodreads	
Share your thoughts	
Sharing	
Sharing is disabled for this title.	
Unable to post. Please try again.	
Unable to retrieve your social network settings. Please try again later.	
Unable to Share. You have reached the clipping limit for this item.	
Weibo	
You must select a social network to use the Sharing feature.	
Your message is being shared.	
1 character over	
