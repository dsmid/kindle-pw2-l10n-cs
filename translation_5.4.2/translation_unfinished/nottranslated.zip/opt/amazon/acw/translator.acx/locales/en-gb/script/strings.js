About Translation	
Aeroplane Mode must be turned off to use this feature.	
An error occurred. Please try again.	
Back to Translation	
Danish	
Detecting...	
Dutch	
English	
Finnish	
French	
From:	
German	
Hindi	
Chinese Simplified	
Chinese Traditional	
Italian	
Japanese	
Korean	
No network detected. Please check your connection and try again.	
Norwegian	
No text was selected for translation.	
Portuguese	
Russian	
Spanish	
To:	
Translating your selection...	
Translation	
Turn Off Aeroplane Mode	
Unable to contact the server. Please try again later.	
Waiting for connection...	
Wireless must be turned on to use this feature.	
Czech	
