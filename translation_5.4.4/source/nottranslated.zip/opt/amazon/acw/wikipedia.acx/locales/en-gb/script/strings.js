Aeroplane Mode must be turned off to use this feature.	
An error occurred. Please try again.	
Launch Wikipedia	
No Wikipedia results were found for your selection.	
No network detected. Please check your connection and try again.	
No text was selected.	
Open Wikipedia ▶	
Search Google ▶	
Searching Wikipedia...	
Turn Off Aeroplane Mode	
Turn On Wireless	
Unable to contact the server. Please try again later.	
Waiting for connection...	
Wikipedia lookups are not available when using FreeTime.	
Wikipedia	
Wireless must be turned on to use this feature.	
