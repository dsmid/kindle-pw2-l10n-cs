Cancel	
Close	
Connection Required	
Edit	
Menu	
OK	
Remove	
Screen Light	
Shop in Kindle Store	
Turn Off Wireless	
Turn On Wireless	
Unable to Connect	
Your Kindle is currently unable to connect.<br><br>Please try again later.	
strings	
