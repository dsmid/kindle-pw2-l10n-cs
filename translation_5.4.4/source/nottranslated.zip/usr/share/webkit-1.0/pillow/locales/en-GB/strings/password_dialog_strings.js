Enter Passcode	
Forgotten Passcode?	
If you have forgotten your passcode, please contact Kindle Customer Service at www.kindle.com/support to receive help resetting your device.	
Incorrect Passcode	
OK	
Passcode Required	
Passcode hint: 	
The passcode you entered is incorrect. Please try again.	
This device has been disabled remotely.	
Your Kindle will reset to factory defaults after 2 more failed attempts.	
Your Kindle will reset to factory defaults after the next failed attempt.	
