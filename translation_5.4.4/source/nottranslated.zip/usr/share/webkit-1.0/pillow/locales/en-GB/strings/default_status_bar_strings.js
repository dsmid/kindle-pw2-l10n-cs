Connected	
Connecting	
 · 	
